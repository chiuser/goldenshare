"""Independent literal state transitions; artificial bars are not software truth."""
from copy import deepcopy
from dataclasses import replace
from datetime import date,timedelta

import pytest

import scripts.research.index_market.xxm.reference_rescue as research
from src.biz.services.wealth.market.index_detail_xxm.types import XxmBar


# A strong old negative segment (P90,D-20), a weaker recent one (P100,D-5),
# then two new green bars (P99/98,D-2/-3). All literal, not generated expected.
VALUES=[(90,-20,-2),(110,1,2),(100,-5,-2),(110,1,2),(99,-2,-2),(98,-3,-2)]


def bar(n,c,d,h=-2):
    return XxmBar((date(2020,1,1)+timedelta(days=n-1)).isoformat(),c,d,d-h/2,h)


def prepared(candidate=True,values=VALUES):
    calc=research.new('day',candidate)
    for n,(c,d,h) in enumerate(values,1):calc.step(bar(n,c,d,h))
    if values==VALUES:
        assert calc.state=='DULL' and calc.reference.price==100 and calc.reference.dif==-5
        assert [(r.price,r.dif) for r in calc.history[-1]]==[(90,-20),(100,-5)]
    return calc


def test_rescue_uses_the_already_known_older_reference_without_new_event():
    calc=prepared();pool=deepcopy(calc.history);step=calc.step(bar(7,89,-6))
    assert calc.state=='DULL' and calc.reference.dif==-20
    assert not step.events and len(calc.rescues)==1
    assert calc.rescues[0]['oldReference']['dif']==-5
    assert calc.history==pool
    base=prepared(False);step=base.step(bar(7,89,-6))
    assert [e['type'] for e in step.events]==['CANCEL'] and base.state=='NONE'


@pytest.mark.parametrize('close,dif',[(95,-6),(90,-6),(89,-20),(89,-21)])
def test_no_price_or_dif_qualified_alternative_preserves_real_cancel(close,dif):
    calc=prepared();step=calc.step(bar(7,close,dif))
    assert [e['type'] for e in step.events]==['CANCEL']
    assert not calc.rescues


def test_old_dif_equality_does_not_request_rescue_or_cancel():
    calc=prepared();step=calc.step(bar(7,89,-5))
    assert not step.events and not calc.rescues and calc.reference.dif==-5


def test_newest_price_gate_cannot_be_bypassed():
    # Recent P80 is lower than older P90. Incoming P85 cannot pass recent P80.
    values=[(90,-20,-2),(110,1,2),(80,-5,-2),(110,1,2),(79,-2,-2),(78,-3,-2)]
    calc=prepared(values=values)
    # Deliberately inject an ineligible active price for the pure gate test;
    # this fabricated state is not presented as a causal software episode.
    calc.wave.price=85;calc.reference=deepcopy(calc.history[-1][-1]);calc.state='DULL'
    assert research.rescue_reference(calc,bar(7,85,-6)) is None


def test_no_proactive_switch_before_old_reference_breaks():
    calc=prepared();step=calc.step(bar(7,89,-4))
    assert not calc.rescues and calc.reference.dif==-5 and not step.events


def test_rescued_reference_can_really_fail_on_the_very_next_bar():
    calc=prepared();calc.step(bar(7,89,-6));step=calc.step(bar(8,88,-21))
    assert [e['type'] for e in step.events]==['CANCEL'] and calc.state=='NONE'
    assert step.events[0]['eventReference']['dif']==-20 and len(calc.rescues)==1


def test_rescue_uses_original_segment_price_not_an_extra_current_close_gate():
    calc=prepared();calc.step(bar(7,89,-4))
    step=calc.step(bar(8,95,-6))
    assert calc.state=='DULL' and calc.reference.price==90 and not step.events
    assert len(calc.rescues)==1 and calc.wave.price==89


def test_following_turn_can_confirm_structure_earlier_than_cancel_then_reenter():
    # Literal counterexample to treating R1 as merely deleting two labels.
    calc=prepared();base=prepared(False)
    calc.step(bar(7,89,-6));base.step(bar(7,89,-6))
    step=calc.step(bar(8,89,-5.9));old_step=base.step(bar(8,89,-5.9))
    assert step.events[0]['type']=='STRUCTURE' and step.events[0]['route']=='dif_turn'
    assert old_step.events[0]['type']=='DULL' and old_step.events[0]['route']=='activation'


def test_structure_state_is_not_rescued():
    calc=prepared();step=calc.step(bar(7,101,-2.95))
    assert step.events[0]['type']=='STRUCTURE'
    step=calc.step(bar(8,89,-6))
    assert step.events[0]['type']=='CANCEL' and not calc.rescues


def test_none_first_entry_is_not_reclassified_as_rescue():
    calc=prepared(values=VALUES[:-1]);step=calc.step(bar(6,89,-6))
    assert step.events[0]['type']=='DULL' and step.events[0]['route']=='activation'
    assert calc.reference.dif==-20 and not calc.rescues


def test_waiting_reference_break_only_ends_wait():
    calc=prepared();calc.step(bar(7,101,-2.95));step=calc.step(bar(8,101,-3.1))
    assert step.events[0]['type']=='STRUCTURE_DISAPPEARED' and calc.pending_rearm is not None
    step=calc.step(bar(9,89,-6))
    assert calc.state=='NONE' and calc.pending_rearm is None and not step.events and not calc.rescues


def test_top_mirror_uses_unchanged_product_cancellation():
    values=[(200-c,-d,-h) for c,d,h in VALUES]
    calc=prepared(values=values);step=calc.step(bar(7,111,6,2))
    assert step.events[0]['direction']=='TOP' and step.events[0]['type']=='CANCEL'
    assert not calc.rescues


@pytest.mark.parametrize('hist', [0,2])
def test_zero_or_red_bar_is_not_rescued(hist):
    calc=prepared();base=prepared(False)
    assert calc.step(bar(7,89,-6,hist))==base.step(bar(7,89,-6,hist))
    assert not calc.rescues


@pytest.mark.parametrize('bad', [replace(bar(7,89,-6),completed=False),replace(bar(7,89,-6),dif=float('nan')),bar(6,89,-6)])
def test_rejected_bar_does_not_mutate_reference(bad):
    calc=prepared();saved=calc.snapshot()
    with pytest.raises(ValueError):calc.step(bad)
    assert calc.snapshot()==saved and not calc.rescues


def test_explicit_research_child_keeps_policy_and_does_not_pollute_parent():
    calc=prepared();saved=calc.snapshot();child=research.child_of(calc)
    assert isinstance(child,research.BottomDullRescueCalculator)
    child.step(bar(7,89,-6))
    assert child.reference.dif==-20 and calc.snapshot()==saved
    restored=research.child_of(child)
    assert restored.snapshot()==child.snapshot()
    assert restored.step(bar(8,89,-7))==child.step(bar(8,89,-7))


def test_output_is_scoped_and_refuses_existing_directory(tmp_path,monkeypatch):
    with pytest.raises(ValueError):research.run(tmp_path/'run_01')
    monkeypatch.setattr(research,'ROOT',tmp_path)
    output=tmp_path/'reports/run_01';output.mkdir(parents=True)
    (output/'kept.txt').write_text('original')
    with pytest.raises(FileExistsError):research.run(output)
    assert (output/'kept.txt').read_text()=='original'
